//
//  ProductTableViewCell.swift
//  Project Task
//
//  Created by Apple on 18/03/23.
//

import UIKit

class ProductTableViewCell: UITableViewCell {
    @IBOutlet weak var labelTitle: UILabel!
    
    @IBOutlet weak var labelPrice: UILabel!
    
    @IBOutlet weak var ratelabel: UILabel!
    @IBOutlet weak var labelSubtitle: UILabel!
    @IBOutlet weak var img: UIImageView!
    
    var product: ListData? {
        didSet { // Property Observer
            productDetailConfiguration()
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    func productDetailConfiguration() {
        guard let title = product?.title ,
              let cat = product?.category,
              let rate = product?.rating.rate,
              let price = product?.price else {
            return
        }
        labelTitle.text = title
        labelSubtitle.text = cat
        labelPrice.text = "Price: $\(price)"
        ratelabel.text =  "Rate: " + "\(rate)"
        img.downlodeImage(serviceurl: product?.image ?? "", placeHolder: UIImage(named: ""))
    }
    
}
