//
//  AddUpdateProductViewModel.swift
//  Project Task
//
//  Created by Apple on 18/03/23.
//

import Foundation


class AddUpdateViewModel : NSObject{
    var callBack:(()->Void)?
    
    func doAdd(title:String, price:String, desc:String, cat:String) {
        guard let url = URL(string: "https://fakestoreapi.com/products") else { return }
        let parameters = AddProductListData(title: title, price: price, description: desc, category: cat)
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        request.httpBody = try? JSONEncoder().encode(parameters)
        
        
        
        request.allHTTPHeaderFields = [
            "Content-Type": "application/json"
        ]
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            
            do {
                guard let data = data else {return}
                let response = try JSONDecoder().decode(AddProductListData.self, from: data)
                print("Added Data is...")
                print(response.title,response.description,response.price,response.category)
                self.callBack?()
                
            }catch {
                print(error)
            }
        }.resume()
    }
}
