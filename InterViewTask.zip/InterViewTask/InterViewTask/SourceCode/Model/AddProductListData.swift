//
//  AddProductListData.swift
//  Project Task
//
//  Created by Apple on 18/03/23.
//

import Foundation


struct AddProductListData: Codable {
    var id: Int? = nil
    var title: String
    var price: String
    var description:String
    var category : String
}
